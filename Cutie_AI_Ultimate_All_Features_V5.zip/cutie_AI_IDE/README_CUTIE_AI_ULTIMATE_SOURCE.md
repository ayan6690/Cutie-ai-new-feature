# Cutie AI Ultimate Source Pack — consolidated edition

This ZIP consolidates the Android Studio app sources, AI endpoint configuration,
workspace/editor, Web Builder, AI analysis/bug-fix screens, Root Automation and
Root Terminal safety guard into one source archive. It also includes a bounded
repair-agent contract (`BoundedRepairAgent.kt`) and a FastAPI build-worker API
contract scaffold under `backend/build-worker`.

## Feature truth / integration status
- **Implemented in app source:** editor text buffer; local workspace save/open;
  compatible chat-completions request; AI plan/website/code generation; AI analysis
  and proposed full-file repair; root access check/device read-only diagnostics;
  explicit root terminal confirmation and basic blocked-command guard.
- **Added source contracts/scaffolds:** bounded build-test-repair loop contracts;
  remote build API request/status contract.
- **Still needs real integration and testing:** actual Gradle build execution in
  an isolated remote worker, APK signing/export, diff approval UI wired to the
  agent interfaces, test instrumentation, secure API-key storage (Android Keystore),
  and full security review.
- **Root is opt-in and user-granted.** This app must not silently elevate or run
  destructive device commands. Root commands can cause data loss/device failure.
- **No compile/runtime claim:** this source pack has not been built or tested here.
  A compatible Android Studio + Android SDK + JDK 17 + Gradle setup is required.

## Build the Android project
1. Extract the ZIP.
2. Open `cutie_AI_IDE/android-app` in Android Studio.
3. Configure Android SDK platform 34 and JDK 17.
4. Sync Gradle, review errors, then run the app on a test device.
5. Configure AI Setup with a provider endpoint, model, and API key.
6. Test Root Automation only on a rooted test device and review each permission prompt.

## Build-worker scaffold
`backend/build-worker/app.py` only provides a non-executing API contract sample.
It intentionally does not execute submitted source. Before enabling builds, implement
an authenticated queue and ephemeral isolated runner with quotas, network restrictions,
artifact scanning, per-user access controls and independent signing consent.

## Ultimate feature additions in this consolidated source pack

### Available in Android source (needs full app build/device QA)
- Voice Coding: Android speech recognition produces a reviewed prompt; user triggers AI request.
- Workspace Backup/Share: exports the current workspace files into a ZIP via Android FileProvider.
- Local Security Scanner: heuristic checks for likely hardcoded secrets, cleartext HTTP,
  WebView JavaScript enabling, root shell invocation, and world-readable/writable modes.
- Ultimate Feature Hub: AI-assisted workflows for multi-agent architecture, security audit,
  unit/UI test generation, database schema, REST/OpenAPI design, docs, performance review,
  Git workflow/rollback planning, deployment planning, local AI integration, screenshot-to-UI
  planning, and plugin-system design.
- MultiRoleOrchestrator contracts: architect/developer/reviewer/QA/security role handoff,
  bounded rounds, and artifact approval gate.
- BoundedRepairAgent contracts: bounded repair proposals and build/test verification interfaces.

### Scaffold/planning only (requires external implementation)
- Gradle Android APK/AAB build execution and signing.
- Isolated cloud build worker; API sample intentionally does not execute submitted source.
- Actual Git commands/repository operations; current hub produces plans only.
- Real deployment, marketplace/plugin runtime, local LLM inference, screenshot image ingestion,
  full SAST, runtime instrumentation, benchmark collection, and database/API backend deployment.
- Automatic patch application requires a concrete PatchApplier, path validation, snapshots,
  user diff review/approval, and test/build service. No silent source mutation is enabled.

## Feature roadmap priority
1. Build an authenticated isolated Gradle worker and integrate job status/artifact download.
2. Add diff review/approval and connect the bounded repair interfaces to real builds/tests.
3. Add secure credential storage (Android Keystore) and provider-specific configuration.
4. Add repository-backed Git operations with explicit confirmation and rollback snapshots.
5. Integrate screenshot/image input and a real visual preview/editor.
6. Implement database/API project templates and test instrumentation.
7. Add local model runtime only after measuring target-device memory/storage and model licensing.
