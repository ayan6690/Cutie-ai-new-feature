# Cutie AI IDE v2 — engineering starter

This revision adds a native dashboard and session-based AI integration to the supplied Android Studio project.

## Included now
- Native Cutie AI dashboard with Editor, AI Developer, Web Builder, Analyze/Auto Bug Fix and Root Terminal sections.
- Local app-private workspace, file save/open, filename traversal checks.
- OpenAI-compatible Chat Completions endpoint support (endpoint/model/key configurable from AI Setup).
- AI-generated HTML/code can be saved into the workspace.
- Root shell command requires an explicit confirmation, runs with a 20-second timeout, and displays exit status/output.
- API key is memory-only and cleared when the Activity is destroyed. Do not share screenshots/logs that expose it.

## Important boundaries
- This is a starter implementation, not a finished production IDE.
- A generated source file is not the same as a built APK. APK building needs Gradle and Android SDK tooling on-device or a remote build worker. This revision does not yet implement a cloud build backend, APK signing, test orchestration, or autonomous verified repair loops.
- AI code results are untrusted. Review generated code before compiling/running it. Root terminal access is powerful and can damage the device.
- The app uses an OpenAI-compatible endpoint. Provider compatibility, model access, billing, and API key are the user's responsibility.
- No claim is made that this project has been compiled or runtime-tested in this environment.

## Next implementation milestones
1. Add a persistent Project Explorer with tree-based workspaces and editor tabs.
2. Integrate a proper code editor (CodeMirror/Monaco in WebView) with syntax highlighting and diagnostics.
3. Add project templates (Android/Kotlin, HTML, JS, Python) and generated file manifests.
4. Add a remote build-worker API: isolated build container, Gradle, SDK, signing flow and downloadable APK artifacts.
5. Add test-driven AI repair loop: build -> parse errors -> propose patch -> apply diff -> rebuild -> run tests, with max attempts and user approval.
6. Add secure credential storage (Android Keystore-backed encryption), provider selection and rate-limit handling.
7. Add permission sandboxing, command allowlisting, audit history and explicit root safety controls.

## Root Automation addition (v2.1 source update)
- Root Automation screen uses `su -c` to invoke device root, relying on Magisk/KernelSU/another root manager to grant or deny the app.
- Root check (`id`), Android build/device properties, third-party package listing, and diagnostic report collection are read-only actions.
- Cache cleanup accepts a validated package name and asks for confirmation twice. `pm clear --cache-only` availability can vary by Android version/vendor; if unsupported, it reports the shell error rather than silently clearing app data.
- Root Terminal continues to allow an entered command only after explicit confirmation, with output/exit status and a 20-second timeout.
- Root access is not silently escalated: a rooted device and user-approved root grant are mandatory. This source has not been compiled or tested on a physical rooted phone in this environment.


# Cutie AI Ultimate V3 Enhancement Notes

## Added in this revision
- AI Project Architect screen: app idea to architecture, screen UX, file tree, API/data design, security considerations, build steps and acceptance tests.
- HTML prototype generator: saves a responsive standalone prototype to the app workspace. Prototype/backend limitations are explicitly disclosed.
- Root terminal safety guard blocks several destructive command patterns (format/wipe, critical device writes, reboot/poweroff, some boot/security property changes) before confirmation.
- AI system instruction emphasizes truthfulness about unexecuted builds/tests and least privilege.

## Ultimate platform roadmap (not implemented by this starter)
1. Multi-file agent workspace with diff review and version snapshots.
2. Build worker: Android Gradle builds in an isolated cloud/desktop runner; parse compiler output.
3. Agent loop: plan -> patch -> build -> test -> inspect logs -> patch; bounded iterations and user-approved changes.
4. Device test integration via Android instrumentation / emulator farm.
5. Web project scaffolding with framework selection, preview, lint/test and deployment adapters.
6. Secure credentials: Android Keystore encrypted storage, key rotation and no key in logs.
7. Root automation allow-list, command audit trail, per-task permissions, undo/backup where possible.
8. Git integration, code review diffs, project memory and reproducible export.
9. Voice, screenshot/UI understanding, accessibility checks, performance and dependency vulnerability checks.
10. Explicit human approval for destructive root operations, signing, publishing, deployments and secrets access.

## Verification status
This source archive has not been compiled or tested on a rooted Android device in this environment. Root availability depends on the user's device and root manager. AI planning/prototype generation requires a compatible endpoint and API key. A true Android APK build/autofix agent needs an external isolated build runner; this app does not claim to build APKs autonomously yet.
