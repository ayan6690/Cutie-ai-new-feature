# Acceptance checklist

## Android app
- [ ] Gradle sync/build succeeds on JDK 17 and SDK 34.
- [ ] Workspace save/open rejects path traversal and preserves UTF-8.
- [ ] AI request shows network/provider failures without exposing API key in logs.
- [ ] Generated code is displayed and saved only after user action.
- [ ] Root check reports `uid=0` only when root manager grants permission.
- [ ] Root read-only diagnostic tasks work on a rooted test device.
- [ ] Root Terminal asks confirmation, applies timeout, and displays exit status.
- [ ] Destructive actions are not automated without explicit approval.

## Agent and build pipeline (future integration)
- [ ] Build worker authenticates project owner and limits archive size.
- [ ] Build runs in disposable sandbox as non-root with CPU/RAM/time quota.
- [ ] Agent attempts are bounded (1–5), patch path traversal is rejected.
- [ ] Diff is shown to user and approval required before patch application.
- [ ] Build and tests run after each patch; only successful verified artifact is marked.
- [ ] Signing secrets are isolated from AI prompts and worker logs.
- [ ] APK output is scanned and downloadable only by job owner.

## Ultimate V4 feature additions
- [ ] Voice Coding speech recognition returns a prompt; user reviews before sending.
- [ ] Workspace backup ZIP contains only files from the app-private workspace.
- [ ] FileProvider grants read-only URI access and sharing works on Android 7+.
- [ ] Local scanner reports heuristic matches with line numbers; no finding is presented as proof.
- [ ] Feature Hub prompts label AI output as proposals/plans, not executed operations.
- [ ] Multi-role orchestration is bounded and requires approval for artifacts.
- [ ] Security scan false positives/negatives are documented.
