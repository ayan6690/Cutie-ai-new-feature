# Cutie AI Build Worker — integration scaffold

This directory describes the remote build-worker boundary. It is **not a production
build service** and does not run arbitrary code from the public internet.

## Required production design
- Place workers in disposable, isolated containers/VMs with no host mounts.
- Accept an authenticated upload with size limits and a project manifest.
- Restrict outbound network by allow-list; pin dependencies where possible.
- Run Gradle under a non-root UID, CPU/memory/time quotas, and a fresh workspace.
- Do not accept signing keys from app prompts. Signing is a separate explicit flow.
- Return logs and APK only after artifact scanning and build completion.
- Add tenant isolation, rate limits, audit events, retention controls, and TLS.
- Never use the phone's `su` privilege for cloud builds.

`app.py` is a small API contract sample only; build execution is intentionally a
stub until you deploy a hardened worker image and security controls.
