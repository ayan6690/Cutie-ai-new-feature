"""Cutie AI build-worker API contract scaffold (not production-ready)."""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from uuid import uuid4

app = FastAPI(title="Cutie AI Build Worker", version="0.1-scaffold")

class BuildRequest(BaseModel):
    project_id: str = Field(min_length=1, max_length=80)
    source_archive_id: str = Field(min_length=1, max_length=160)
    target: str = Field(pattern="^(android|web)$")
    # Never include credentials or signing secrets in this request.

class BuildStatus(BaseModel):
    job_id: str
    state: str
    message: str

@app.post("/v1/builds", response_model=BuildStatus, status_code=202)
def create_build(req: BuildRequest):
    # TODO production: authenticate, authorize project ownership, enforce quotas,
    # validate archive, enqueue to isolated ephemeral worker. No shell is invoked here.
    job_id = str(uuid4())
    return BuildStatus(job_id=job_id, state="queued",
                       message="Scaffold only: isolated worker not configured")

@app.get("/v1/builds/{job_id}", response_model=BuildStatus)
def get_build(job_id: str):
    # TODO read state from authenticated job store; scope job to owner.
    if len(job_id) > 80:
        raise HTTPException(status_code=404, detail="Job not found")
    return BuildStatus(job_id=job_id, state="not-configured",
                       message="Connect a real worker and job store")
