package com.cutie.rootide.features

/** Lightweight heuristic source scanner. This is not a substitute for SAST or runtime testing. */
data class SecurityFinding(
    val severity: Severity,
    val rule: String,
    val line: Int,
    val evidence: String,
    val recommendation: String
) {
    enum class Severity { HIGH, MEDIUM, LOW }
}

class LocalSecurityScanner {
    fun scan(source: String): List<SecurityFinding> {
        val rules = listOf(
            Rule("POSSIBLE_HARDCODED_SECRET", SecurityFinding.Severity.HIGH,
                Regex("(?i)(api[_-]?key|secret|password|token)\\s*[:=]\\s*[\\\"'][^\\\"']{8,}[\\\"']"),
                "Move secrets to secure server-side storage or Android Keystore; rotate exposed credentials."),
            Rule("CLEAR_TEXT_HTTP", SecurityFinding.Severity.MEDIUM,
                Regex("http://(?!localhost|127\\.0\\.0\\.1)[^\\s\\\"']+"),
                "Prefer HTTPS and validate certificates; avoid sending sensitive data over cleartext."),
            Rule("WEBVIEW_JAVASCRIPT_ENABLED", SecurityFinding.Severity.MEDIUM,
                Regex("(?i)setJavaScriptEnabled\\s*\\(\\s*true\\s*\\)"),
                "Enable JavaScript only for trusted content; disable file access and restrict navigation."),
            Rule("ROOT_SHELL_INVOCATION", SecurityFinding.Severity.HIGH,
                Regex("(?i)(ProcessBuilder|Runtime\\.getRuntime\\(\\)\\.exec)\\s*\\([^\\n]*(su|sh)"),
                "Use least privilege, require explicit user consent, allow-list commands and enforce timeout."),
            Rule("WORLD_WRITABLE_MODE", SecurityFinding.Severity.HIGH,
                Regex("(?i)MODE_WORLD_(READABLE|WRITABLE)"),
                "Use app-private storage and narrowly scoped content-provider sharing.")
        )
        val findings = mutableListOf<SecurityFinding>()
        source.lines().forEachIndexed { index, line ->
            rules.forEach { rule ->
                if (rule.pattern.containsMatchIn(line)) findings += SecurityFinding(
                    rule.severity, rule.id, index + 1, line.trim().take(180), rule.recommendation
                )
            }
        }
        return findings.distinctBy { "${it.rule}:${it.line}" }
    }

    private data class Rule(
        val id: String,
        val severity: SecurityFinding.Severity,
        val pattern: Regex,
        val recommendation: String
    )
}
