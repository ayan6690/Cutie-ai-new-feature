package com.cutie.rootide.features

/** Contracts for a multi-role agent pipeline. Provider/tool implementations are injected. */
enum class AgentRole { ARCHITECT, DEVELOPER, REVIEWER, QA, SECURITY }

data class AgentTask(val id: String, val goal: String, val context: String, val role: AgentRole)
data class AgentResult(val role: AgentRole, val summary: String, val artifacts: Map<String, String>, val warnings: List<String>)

interface RoleAgent {
    suspend fun execute(task: AgentTask, priorResults: List<AgentResult>): AgentResult
}

interface HumanApprovalGate {
    /** Return true only after the user explicitly approves the proposed artifacts/actions. */
    suspend fun approve(result: AgentResult): Boolean
}

/** Sequential role handoff keeps context auditable; it does not execute shell/build actions. */
class MultiRoleOrchestrator(
    private val agents: Map<AgentRole, RoleAgent>,
    private val approvalGate: HumanApprovalGate,
    private val maxRounds: Int = 2
) {
    suspend fun run(taskId: String, goal: String, context: String): List<AgentResult> {
        require(maxRounds in 1..3) { "maxRounds must be 1..3" }
        val history = mutableListOf<AgentResult>()
        val roles = listOf(AgentRole.ARCHITECT, AgentRole.DEVELOPER, AgentRole.REVIEWER, AgentRole.QA, AgentRole.SECURITY)
        repeat(maxRounds) { round ->
            for (role in roles) {
                val agent = agents[role] ?: continue
                val task = AgentTask("$taskId-$round-${role.name.lowercase()}", goal, context, role)
                val result = agent.execute(task, history.toList())
                history += result
                if (result.artifacts.isNotEmpty() && !approvalGate.approve(result)) {
                    return history + AgentResult(role, "Stopped: user declined artifact approval.", emptyMap(), listOf("No artifact was applied."))
                }
            }
        }
        return history
    }
}
