package com.cutie.rootide.agent

/**
 * Bounded AI repair workflow contracts.
 *
 * The host app/backend must implement BuildRunner and PatchProvider. This class does
 * not claim a fix is verified unless a build and tests return success.
 */
data class BuildReport(
    val success: Boolean,
    val log: String,
    val artifactPath: String? = null
)

data class PatchProposal(
    val summary: String,
    val unifiedDiff: String,
    val filesTouched: List<String>
)

interface BuildRunner {
    suspend fun buildAndTest(projectPath: String): BuildReport
}

interface PatchProvider {
    suspend fun proposePatch(projectPath: String, buildLog: String): PatchProposal?
}

interface PatchApplier {
    /** Must validate paths, reject traversal, create a snapshot, and apply only reviewed diffs. */
    suspend fun applyReviewedPatch(projectPath: String, proposal: PatchProposal): Boolean
}

data class RepairOutcome(
    val verified: Boolean,
    val attempts: Int,
    val finalReport: BuildReport,
    val history: List<String>
)

/**
 * Repair loop bounded by maxAttempts. A real UI should present each diff for approval.
 * The caller must supply a PatchApplier that enforces approval and path validation.
 */
class BoundedRepairAgent(
    private val builder: BuildRunner,
    private val patchProvider: PatchProvider,
    private val patchApplier: PatchApplier,
    private val maxAttempts: Int = 3
) {
    suspend fun repair(projectPath: String): RepairOutcome {
        require(maxAttempts in 1..5) { "maxAttempts must be 1..5" }
        val history = mutableListOf<String>()
        var report = builder.buildAndTest(projectPath)
        if (report.success) {
            history += "Initial build and tests passed."
            return RepairOutcome(true, 0, report, history)
        }

        for (attempt in 1..maxAttempts) {
            history += "Attempt $attempt: build failed; asking AI for a patch."
            val proposal = patchProvider.proposePatch(projectPath, report.log)
            if (proposal == null) {
                history += "AI did not return a patch."
                break
            }
            history += "Proposal: ${proposal.summary}; files: ${proposal.filesTouched.joinToString()}"
            val applied = patchApplier.applyReviewedPatch(projectPath, proposal)
            if (!applied) {
                history += "Patch not applied (approval/path validation failed)."
                break
            }
            report = builder.buildAndTest(projectPath)
            if (report.success) {
                history += "Build and tests passed after attempt $attempt."
                return RepairOutcome(true, attempt, report, history)
            }
            history += "Build/tests still failing after attempt $attempt."
        }
        return RepairOutcome(false, history.count { it.startsWith("Attempt ") }, report, history)
    }
}
