package com.cutie.rootide

import android.app.AlertDialog
import android.content.Intent
import android.speech.RecognizerIntent
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Cutie AI IDE v2 starter: editor/workspace + OpenAI-compatible AI endpoint. */
class MainActivity : AppCompatActivity() {
    private val worker = Executors.newSingleThreadExecutor()
    private val workspace by lazy { File(filesDir, "workspace").apply { mkdirs() } }
    private var apiBase = "https://api.openai.com/v1/chat/completions"
    private var model = "gpt-4o-mini"
    // Kept in memory only for this app session. Do not log or persist this value.
    private var apiKey = ""
    private lateinit var root: LinearLayout
    private lateinit var filename: EditText
    private lateinit var editor: EditText
    private lateinit var prompt: EditText
    private lateinit var output: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Cutie AI"
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16)); setBackgroundColor(0xFF0B1020.toInt())
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        showHome()
    }

    private fun showHome() {
        root.removeAllViews()
        root.addView(text("CUTIE AI", 27f, 0xFF9DBBFF.toInt()))
        root.addView(text("AI IDE • App Builder • Web Builder • Bug Fixer", 13f, 0xFFB8C5DC.toInt()))
        root.addView(space(12))
        addAction("Open Code Editor", "Edit source files, save and open workspace files") { showEditor() }
        addAction("AI Developer", "Ask AI to plan, write, explain or improve code") { showAi() }
        addAction("AI Project Architect", "Design a multi-screen app, file tree, implementation and test plan") { showProjectArchitect() }
        addAction("Build a Website", "Generate a starter HTML website with AI") { showWebBuilder() }
        addAction("Analyze / Auto Bug Fix", "Ask AI to inspect code and propose a corrected version") { showBugFix() }
        addAction("Root Automation", "Run approved root-powered device tasks") { showRootAutomation() }
        addAction("Root Terminal", "Root shell is dangerous; every command requires confirmation") { showTerminal() }
        addAction("Ultimate Feature Hub", "Security, tests, DB/API, Git plans, docs, performance, multi-agent") { showFeatureHub() }
        addAction("Local Security Scanner", "Heuristic scan of pasted code for common risky patterns") { showLocalSecurityScanner() }
        addAction("Voice Coding", "Speak a prompt using Android speech recognition") { startVoiceCoding() }
        addAction("Workspace Backup / Share", "Package workspace files as a ZIP and share/export") { backupWorkspace() }
        addAction("AI Setup", "Configure compatible API URL, model and API key") { setupAi() }
        root.addView(space(12))
        root.addView(text("Workspace: ${workspace.absolutePath}", 12f, 0xFF8E9BB3.toInt()))
        root.addView(text("Build/export note: this starter generates source files. A full Android APK build pipeline needs a configured local or cloud Gradle build service.", 12f, 0xFFFFD28A.toInt()))
    }

    private fun showLocalSecurityScanner() {
        root.removeAllViews()
        root.addView(text("LOCAL SECURITY SCANNER", 22f, 0xFFFFC27A.toInt()))
        root.addView(text("Heuristic source scan only; findings need human review and this is not a full SAST/runtime security test.", 13f, 0xFFB8C5DC.toInt()))
        val source = edit("Paste Kotlin/Java/JS/Python source here…", true).apply { minLines = 12; gravity = Gravity.TOP }
        root.addView(source)
        val report = text("Scan report will appear here.", 13f, 0xFFEAF0FF.toInt())
        root.addView(report)
        addAction("Scan Source", "Detect possible hardcoded secrets, cleartext HTTP, WebView JS, root shell and unsafe modes") {
            val findings = com.cutie.rootide.features.LocalSecurityScanner().scan(source.text.toString())
            report.text = if (findings.isEmpty()) "No patterns detected. This does not prove the code is secure." else findings.joinToString("\n\n") {
                "${it.severity} — ${it.rule} (line ${it.line})\n${it.evidence}\nFix: ${it.recommendation}"
            }
        }
        addAction("AI Review Findings", "Ask configured AI to supplement this heuristic scan") {
            askAi("Review this source for security vulnerabilities. This local scanner is heuristic; independently assess the code and suggest safe fixes with severity and tests. Do not claim dynamic testing.\n\n${source.text}", false)
        }
        addBack()
    }

    private fun showFeatureHub() {
        root.removeAllViews()
        root.addView(text("ULTIMATE FEATURE HUB", 22f, 0xFF9DBBFF.toInt()))
        root.addView(text("These workflows ask the configured AI to create reviewable project artifacts. They do not claim remote build, deploy, tests, or Git actions unless a real tool is connected.", 13f, 0xFFB8C5DC.toInt()))
        val features = listOf(
            Triple("Multi-Agent Architect", "Coordinate architect, developer, reviewer and QA roles in a structured plan", "Design a multi-agent software engineering workflow for this project. Create role prompts, shared task schema, handoff protocol, bounded iterations, approval gates and failure handling. Return a complete implementation plan and Kotlin/Python interfaces."),
            Triple("Security Audit", "Review source for vulnerabilities and risky permissions", "Perform a security review of the project/source supplied by user. Identify findings with severity, file/line if available, exploit preconditions, safe remediation and regression tests. Focus on OWASP mobile, secrets, WebView, storage, network and permission risks. Do not claim runtime scan."),
            Triple("Unit & UI Test Generator", "Generate test cases and test code", "Generate test strategy, unit tests, Android instrumentation/UI test examples, edge cases and commands for the described project. Clearly label dependencies and tests that have not been run."),
            Triple("Database Builder", "Draft schema, migrations and data layer", "Design a database for this project. Provide normalized schema, indexes, migrations, repository pattern, validation, privacy and backup considerations. Return complete starter code and setup notes."),
            Triple("REST API Builder", "Draft endpoints, models and API tests", "Design a REST API for this project. Provide OpenAPI 3 specification, request/response models, authentication, validation, error handling, rate limits and sample integration/tests. Clearly mark backend components not implemented."),
            Triple("Documentation Generator", "README, architecture and setup docs", "Generate a complete project README, architecture overview, setup/build instructions, configuration, feature status, troubleshooting and API docs based only on supplied project details. Avoid claiming unverified behavior."),
            Triple("Performance Analyzer", "Review performance risks and optimization ideas", "Analyze this project/code for performance and memory risks. Provide prioritized findings, measurements needed, concrete code improvements and benchmarks. Do not invent measured values."),
            Triple("Git Workflow Planner", "Generate safe Git commands and rollback plan", "Create a Git workflow plan with branch naming, checkpoint commits, diff review, rollback strategy and safe commands. Do not claim to execute Git. Explain each command before use."),
            Triple("Web Deployment Planner", "Prepare deployable website bundle and instructions", "Prepare a production deployment checklist for this web project: build output, environment variables, secrets, hosting options, CSP, HTTPS, accessibility, smoke tests and rollback. Do not claim deployment."),
            Triple("Offline AI Integration Plan", "Evaluate local model options and device constraints", "Create an offline/local AI integration plan for Android/Termux. Compare model sizes, quantization, memory/storage, inference options, licensing and safety. Avoid asserting current compatibility without device benchmarks."),
            Triple("Screenshot-to-UI Plan", "Describe conversion of a UI reference into code", "Given the user's UI description/reference, propose screen hierarchy, reusable components, design tokens, accessibility, responsive behavior and Compose/XML/HTML starter code. Ask for image input if none is supplied."),
            Triple("Plugin System Design", "Create extension API and plugin sandbox plan", "Design a secure plugin/extension system: manifest, capability permissions, lifecycle, API versioning, sandboxing, signing, marketplace review and example plugin. Plugins must not silently gain root privileges.")
        )
        features.forEach { item -> addAction(item.first, item.second) {
            prompt = edit("Describe project context and constraints…", true).apply { minLines = 5; setText("Project context: Cutie AI Ultimate\nFeature: ${item.first}\n\n") }
            root.addView(prompt)
            addAction("Generate ${item.first} Artifact", "AI output will be shown for review") { askAi(item.third + "\n\nUser project context: " + prompt.text, false) }
        } }
        addBack()
    }

    private fun startVoiceCoding() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Cutie AI-কে কী তৈরি করতে বলবে?")
            }
            startActivityForResult(intent, 4201)
        } catch (e: Exception) {
            Toast.makeText(this, "Speech recognition unavailable: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Activity result callback for speech input")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 4201 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) {
                showAi()
                prompt.setText(spoken)
                Toast.makeText(this, "Voice prompt ready. Review and tap Generate.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun backupWorkspace() {
        val files = workspace.listFiles()?.filter { it.isFile } ?: emptyList()
        if (files.isEmpty()) { Toast.makeText(this, "Workspace is empty", Toast.LENGTH_SHORT).show(); return }
        val backup = File(cacheDir, "cutie-workspace-${System.currentTimeMillis()}.zip")
        try {
            java.util.zip.ZipOutputStream(backup.outputStream()).use { zos ->
                files.forEach { file ->
                    val entry = java.util.zip.ZipEntry(file.name)
                    zos.putNextEntry(entry)
                    file.inputStream().use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }
            val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", backup)
            val share = Intent(Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(share, "Export Cutie workspace backup"))
        } catch (e: Exception) {
            Toast.makeText(this, "Backup/export failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showEditor() {
        root.removeAllViews(); root.addView(text("CODE EDITOR", 22f, 0xFF9DBBFF.toInt()))
        filename = edit("File name (e.g. main.kt)", false)
        editor = edit("Source code", true).apply { minLines = 14; gravity = Gravity.TOP }
        root.addView(filename); root.addView(editor)
        val row = horizontal()
        actionButton("New", row) { filename.setText("untitled.kt"); editor.setText("") }
        actionButton("Save", row) { saveEditor() }
        actionButton("Open", row) { openFile() }
        root.addView(row)
        addAction("AI: Explain this code", "Send editor content to configured AI") { askAi("Explain this code in clear steps.\n\n${editor.text}", false) }
        addAction("AI: Improve this code", "Ask AI for a revised code version") { askAi("Improve this code. Return only the complete source code, no markdown fences.\n\n${editor.text}", true) }
        addBack()
    }

    private fun showAi() {
        root.removeAllViews(); root.addView(text("AI DEVELOPER", 22f, 0xFF9DBBFF.toInt()))
        prompt = edit("Describe the app, feature, or code task…", true).apply { minLines = 5; gravity = Gravity.TOP }
        root.addView(prompt)
        addAction("Generate / Ask AI", "Uses the API setup configured in AI Setup") { askAi(prompt.text.toString(), true) }
        addAction("Plan a complete app", "Generate a structured implementation plan") { askAi("Create a practical implementation plan for: ${prompt.text}. Include architecture, screens, files, build and test steps.", false) }
        addBack()
    }

    private fun showWebBuilder() {
        root.removeAllViews(); root.addView(text("WEB BUILDER", 22f, 0xFF9DBBFF.toInt()))
        prompt = edit("What website should Cutie build?", true).apply { minLines = 4; gravity = Gravity.TOP }
        root.addView(prompt)
        addAction("Generate Website HTML", "AI will return a single-file HTML page") {
            askAi("Create a complete responsive modern website for: ${prompt.text}. Return ONLY valid standalone HTML with embedded CSS and JS.", true, "index.html")
        }
        addBack()
    }

    private fun showBugFix() {
        root.removeAllViews(); root.addView(text("ANALYZE & AUTO BUG FIX", 22f, 0xFF9DBBFF.toInt()))
        filename = edit("Source filename", false)
        editor = edit("Paste code or error log here…", true).apply { minLines = 10; gravity = Gravity.TOP }
        root.addView(filename); root.addView(editor)
        addAction("Analyze Code", "AI reviews possible errors and explains findings") {
            askAi("Analyze this source/error log. List bugs, severity, causes and tests.\n\n${editor.text}", false)
        }
        addAction("Auto Fix Code", "AI returns a corrected full source file") {
            askAi("Find and fix bugs in this code. Return ONLY the complete corrected source code, no markdown fences. Preserve behavior where possible.\n\n${editor.text}", true, filename.text.toString().ifBlank { "fixed.txt" })
        }
        addBack()
    }



    private fun showProjectArchitect() {
        root.removeAllViews()
        root.addView(text("AI PROJECT ARCHITECT", 22f, 0xFF9DBBFF.toInt()))
        root.addView(text("Describe your app. Cutie will draft architecture, screens, files, milestones, build steps and test cases. Review the plan before implementation.", 13f, 0xFFB8C5DC.toInt()))
        prompt = edit("App idea, target users, features, design preferences, Android/Web…", true).apply { minLines = 7; gravity = Gravity.TOP }
        root.addView(prompt)
        addAction("Create Engineering Plan", "Architecture + file tree + API/data design + test checklist") {
            val idea = prompt.text.toString().trim()
            if (idea.isBlank()) { Toast.makeText(this, "Describe your project first", Toast.LENGTH_SHORT).show(); return@addAction }
            askAi("You are Cutie AI's senior software architect. Produce a practical engineering blueprint for this project: $idea\n\nInclude: (1) clarified assumptions, (2) MVP and later-phase feature split, (3) architecture and components, (4) screen-by-screen UX, (5) repository file tree, (6) data model and API contracts where relevant, (7) dependencies, (8) security/privacy risks, (9) build instructions, (10) acceptance tests and edge cases. Do not claim code is built or tested. Mark any cloud services/API keys needed.", false)
        }
        addAction("Create Starter Files", "Generate a starter single-file web prototype into workspace") {
            val idea = prompt.text.toString().trim()
            if (idea.isBlank()) { Toast.makeText(this, "Describe your project first", Toast.LENGTH_SHORT).show(); return@addAction }
            askAi("Create a polished responsive prototype for this project: $idea. Return ONLY complete standalone HTML with embedded CSS and vanilla JavaScript. Include accessible controls, mobile responsive layout, realistic demo data, and comments identifying mock functions that require backend integration. Do not claim production backend exists.", true, "prototype.html")
        }
        addBack()
    }

    /** Runs a command through the installed su provider. Root access is device/user controlled. */
    private fun runRoot(command: String, timeoutSeconds: Long = 20): String {
        val outputFile = File(cacheDir, "root-output-${System.nanoTime()}.txt")
        return try {
            val process = ProcessBuilder("su", "-c", command)
                .redirectErrorStream(true).redirectOutput(outputFile).start()
            if (!process.waitFor(timeoutSeconds, TimeUnit.SECONDS)) {
                process.destroyForcibly()
                "Timed out after ${timeoutSeconds}s\n${outputFile.takeIf { it.exists() }?.readText().orEmpty()}"
            } else {
                "Exit ${process.exitValue()}\n${outputFile.takeIf { it.exists() }?.readText().orEmpty()}"
            }
        } catch (e: Exception) {
            "Root unavailable / su failed: ${e.message}"
        } finally {
            outputFile.delete()
        }
    }

    private fun isBlockedRootCommand(command: String): Boolean {
        val normalized = command.lowercase().replace(Regex("\\s+"), " ").trim()
        val blockedPatterns = listOf(
            Regex("(^|[;&| ])rm -rf /($|[ ;])"),
            Regex("(^|[;&| ])mkfs([. ]|$)"),
            Regex("(^|[;&| ])dd .*of=/dev/(block|.*)"),
            Regex("(^|[;&| ])(reboot|poweroff|shutdown)( |$)"),
            Regex("(^|[;&| ])(wipefs|format)( |$)"),
            Regex("(^|[;&| ])setprop (.*boot|.*verifiedboot|.*secure)"),
            Regex("(^|[;&| ])(fastboot|flash)( |$)")
        )
        return blockedPatterns.any { it.containsMatchIn(normalized) }
    }

    private fun shellQuote(value: String) = "'" + value.replace("'", "'\\''") + "'"

    private fun showRootAutomation() {
        root.removeAllViews()
        root.addView(text("ROOT AUTOMATION", 22f, 0xFFFFC27A.toInt()))
        root.addView(text("These tasks use su. The phone's root manager will request/deny access. Read-only tasks are available first; destructive actions require a second confirmation.", 13f, 0xFFB8C5DC.toInt()))
        val result = text("Choose an automation task.", 13f, 0xFFEAF0FF.toInt())
        root.addView(result)
        fun runTask(label: String, command: String, timeout: Long = 20) {
            result.text = "$label\nRunning…"
            worker.execute {
                val response = runRoot(command, timeout)
                runOnUiThread { result.text = "$label\n$response" }
            }
        }
        addAction("Check Root Access", "Run id and verify uid=0") { runTask("Root check", "id") }
        addAction("Device Information", "Read Android properties and build details") {
            runTask("Device info", "echo '--- id ---'; id; echo '--- Android ---'; getprop ro.build.version.release; echo '--- SDK ---'; getprop ro.build.version.sdk; echo '--- device ---'; getprop ro.product.device; echo '--- manufacturer ---'; getprop ro.product.manufacturer; echo '--- fingerprint ---'; getprop ro.build.fingerprint")
        }
        addAction("List Installed Packages", "Read package list via package manager") {
            runTask("Installed packages", "pm list packages -3 | sort", 30)
        }
        addAction("Collect Diagnostic Report", "Save read-only root diagnostic text to workspace") {
            result.text = "Collecting diagnostic report…"
            worker.execute {
                val response = runRoot("echo '=== id ==='; id; echo '=== build ==='; getprop ro.build.fingerprint; echo '=== sdk ==='; getprop ro.build.version.sdk; echo '=== packages ==='; pm list packages -3; echo '=== mount summary ==='; mount | head -80", 30)
                val report = File(workspace, "root-diagnostic-${System.currentTimeMillis()}.txt")
                val saveResult = try { report.writeText(response); "\nSaved: ${report.name}" } catch (e: Exception) { "\nSave failed: ${e.message}" }
                runOnUiThread { result.text = response + saveResult }
            }
        }
        addAction("Clear App Cache (Root)", "Enter package name; confirmation required") {
            val packageInput = EditText(this).apply { hint = "e.g. com.example.app"; setTextColor(0xFF111111.toInt()) }
            AlertDialog.Builder(this).setTitle("Clear application cache")
                .setMessage("This removes cache for the package you enter. Do not use a package you do not own/manage.")
                .setView(packageInput).setNegativeButton("Cancel", null)
                .setPositiveButton("Continue") { _, _ ->
                    val pkg = packageInput.text.toString().trim()
                    if (!pkg.matches(Regex("[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+"))) {
                        result.text = "Invalid package name."
                    } else {
                        AlertDialog.Builder(this).setTitle("Confirm cache removal")
                            .setMessage("Run pm clear --cache-only for $pkg? (Some Android versions may not support this option.)")
                            .setNegativeButton("Cancel", null).setPositiveButton("Run") { _, _ ->
                                runTask("Clear cache $pkg", "pm clear --cache-only ${shellQuote(pkg)}")
                            }.show()
                    }
                }.show()
        }
        addBack()
    }

    private fun showTerminal() {
        root.removeAllViews(); root.addView(text("ROOT TERMINAL", 22f, 0xFFFFC27A.toInt()))
        val cmd = edit("Command (example: id)", false); root.addView(cmd)
        val result = text("Terminal output appears here.", 13f, 0xFFB8C5DC.toInt()); root.addView(result)
        actionButton("Run with su", root) {
            val value = cmd.text.toString().trim()
            if (value.isBlank()) { result.text = "Enter a command."; return@actionButton }
            if (isBlockedRootCommand(value)) {
                result.text = "Blocked by Cutie safety guard: this command can wipe data, format storage, or alter critical boot/system partitions. Use a trusted specialist tool and understand the risks before proceeding."
                return@actionButton
            }
            AlertDialog.Builder(this).setTitle("Confirm root command")
                .setMessage("This runs with device root privileges and may damage data or the OS. Only execute commands you understand.\n\n$value")
                .setNegativeButton("Cancel", null).setPositiveButton("Run") { _, _ ->
                    result.text = "Running…"
                    worker.execute {
                        val out = runRoot(value, 20)
                        runOnUiThread { result.text = out }
                    }
                }.show()
        }
        addBack()
    }

    private fun setupAi() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16)) }
        val url = EditText(this).apply { setText(apiBase); hint = "API endpoint" }
        val mdl = EditText(this).apply { setText(model); hint = "Model name" }
        val key = EditText(this).apply { hint = "API key (session-only)"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        panel.addView(text("OpenAI-compatible Chat Completions endpoint", 14f, 0xFFB8C5DC.toInt())); panel.addView(url); panel.addView(mdl); panel.addView(key)
        AlertDialog.Builder(this).setTitle("AI Setup").setView(panel).setNegativeButton("Cancel", null)
            .setPositiveButton("Use for session") { _, _ ->
                apiBase = url.text.toString().trim(); model = mdl.text.toString().trim(); apiKey = key.text.toString()
                Toast.makeText(this, if (apiKey.isNotBlank()) "AI configured for this session" else "API key missing", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun askAi(userPrompt: String, applyCode: Boolean, saveAs: String? = null) {
        if (apiKey.isBlank()) { setupAi(); Toast.makeText(this, "Set API key then retry", Toast.LENGTH_LONG).show(); return }
        val status = text("AI working…", 13f, 0xFFB8C5DC.toInt()); root.addView(status)
        worker.execute {
            val response = try {
                val connection = (URL(apiBase).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 20000; readTimeout = 60000; doOutput = true
                    setRequestProperty("Content-Type", "application/json"); setRequestProperty("Authorization", "Bearer $apiKey")
                }
                val payload = JSONObject().put("model", model).put("messages", JSONArray().put(JSONObject().put("role", "system").put("content", "You are Cutie AI, a careful software engineering assistant. Be honest about limitations and never claim a build, test, root command, or deployment happened unless the app actually executed it and received evidence. Prefer least privilege. For root/device tasks, explain risk and require explicit human confirmation; never suggest silent persistence, stealth, credential theft, or destructive device actions. For code generation requests, return complete code when asked." )).put(JSONObject().put("role", "user").put("content", userPrompt)))
                connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
                val body = stream.bufferedReader().use { it.readText() }
                if (connection.responseCode !in 200..299) "API error ${connection.responseCode}: $body"
                else JSONObject(body).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            } catch (e: Exception) { "AI request failed: ${e.message}" }
            runOnUiThread {
                status.text = response
                if (applyCode && saveAs != null && !response.startsWith("API error") && !response.startsWith("AI request failed")) {
                    val clean = response.replace(Regex("^```[\\w-]*\\s*"), "").replace(Regex("\\s*```$"), "")
                    val name = safeFilename(saveAs)
                    if (name != null) { File(workspace, name).writeText(clean); status.text = "Generated and saved: $name\n\n$clean" }
                }
            }
        }
    }

    private fun saveEditor() {
        val name = safeFilename(filename.text.toString()) ?: run { Toast.makeText(this, "Invalid filename", Toast.LENGTH_SHORT).show(); return }
        try { File(workspace, name).writeText(editor.text.toString()); Toast.makeText(this, "Saved $name", Toast.LENGTH_SHORT).show() }
        catch (e: Exception) { Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show() }
    }
    private fun openFile() {
        val files = workspace.listFiles()?.filter { it.isFile }?.sortedBy { it.name } ?: emptyList()
        if (files.isEmpty()) { Toast.makeText(this, "Workspace is empty", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("Open file").setItems(files.map { it.name }.toTypedArray()) { _, i -> filename.setText(files[i].name); editor.setText(files[i].readText()) }.setNegativeButton("Cancel", null).show()
    }
    private fun safeFilename(input: String): String? {
        val n = input.trim()
        if (n.isBlank() || n == "." || n == ".." || n.contains("..") || n.contains('/') || n.contains('\\') || n.any { it.isISOControl() }) return null
        return n
    }
    private fun addAction(title: String, subtitle: String, action: () -> Unit) {
        val b = Button(this).apply { text = "$title\n$subtitle"; setTextColor(0xFFEAF0FF.toInt()); setBackgroundColor(0xFF1B2740.toInt()); setOnClickListener { action() } }
        root.addView(b, LinearLayout.LayoutParams(-1, dp(64)).apply { bottomMargin = dp(8) })
    }
    private fun actionButton(label: String, parent: LinearLayout, action: () -> Unit) {
        parent.addView(Button(this).apply { text = label; setOnClickListener { action() } }, if (parent.orientation == LinearLayout.HORIZONTAL) LinearLayout.LayoutParams(0, dp(48), 1f) else LinearLayout.LayoutParams(-1, dp(48)))
    }
    private fun horizontal() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    private fun addBack() { root.addView(space(10)); actionButton("← Home", root) { showHome() } }
    private fun edit(hintText: String, multiline: Boolean) = EditText(this).apply {
        hint = hintText; setTextColor(0xFFF1F5FF.toInt()); setHintTextColor(0xFF8593AD.toInt()); setPadding(dp(12)); setBackgroundColor(0xFF172238.toInt())
        inputType = if (multiline) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS else InputType.TYPE_CLASS_TEXT
        if (multiline) minLines = 5
    }
    private fun text(value: String, size: Float, color: Int) = TextView(this).apply { text = value; textSize = size; setTextColor(color); setPadding(0, dp(8), 0, dp(8)) }
    private fun space(height: Int) = TextView(this).apply { this.height = dp(height) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    override fun onDestroy() { apiKey = ""; worker.shutdownNow(); super.onDestroy() }
}
